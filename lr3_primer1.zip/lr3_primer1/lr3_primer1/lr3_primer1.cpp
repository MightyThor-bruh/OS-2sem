﻿// lr3_primer1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "windows.h"
#include <iostream>
#include <tlhelp32.h>
#include "string.h"

const WORD colors[] =
{
0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
};

int main()
{
    HANDLE consoleOutput;
    COORD cursorPos;
    // Получаем хэндл консоли 
    consoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    WORD   index = 0;
    // Remember how things were when we started
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(consoleOutput, &csbi);
    // Задаем координаты курсора и перемещаем курсор
    cursorPos.X = 30;
    cursorPos.Y = 3;
    SetConsoleCursorPosition(consoleOutput, cursorPos);
    SetConsoleTextAttribute(consoleOutput, 0xEC);
    // Выводим строку
    printf("Test string at position (30, 3)");
    // Повторяем с другими координатами...
    cursorPos.X = 15;
    cursorPos.Y = 8;
    SetConsoleCursorPosition(consoleOutput, cursorPos);
    index++;
    SetConsoleTextAttribute(consoleOutput, colors[index]);
    printf("Test string at position (15, 8)");
    getchar();
    return 0;
}


// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
