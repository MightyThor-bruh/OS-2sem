﻿// lr3_primer2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "windows.h"
#include <iostream>
#include <tlhelp32.h>
#include "string.h"
using namespace std;
//typedef BOOL (WINAPI *SETCONSOLEFONT)(HANDLE, DWORD);     // прототип недокументированый функции
// SETCONSOLEFONT SetConsoleFont;

const WORD colors[] =
		{
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
		};

int main()
{
	//HANDLE hstdin  = GetStdHandle( STD_INPUT_HANDLE  );заголовок потока ввода
	HANDLE hstdout = GetStdHandle( STD_OUTPUT_HANDLE );
	int   index   = 0;
	// Remember how things were when we started
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo( hstdout, &csbi );//объект запоминающий даннные о атрибутах консоли
	// Tell the user how to stop
	SetConsoleTextAttribute( hstdout, 0xEC );
	//cout << "Press any key to quit.\n";
	printf ("press any key \n");
	while (index<13)
	{
		SetConsoleTextAttribute( hstdout, colors[ index ] );
		//cout << "\t\t\t\t Hello World \t\t\t\t" << std::endl;
		printf("\t\t\t\t Hello World \t\t\t\t\n");
		cout<<"sizeof(colors):"<<sizeof(colors)<<endl;
		cout<<"sizeof(colors[0])"<<sizeof(colors[0])<<endl;
		if (++index > sizeof(colors)/sizeof(colors[0]))
			break;
	}
	//FlushConsoleInputBuffer( hstdin ); // очистить буфер 
	SetConsoleTextAttribute( hstdout, csbi.wAttributes );
    getchar();
	return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
